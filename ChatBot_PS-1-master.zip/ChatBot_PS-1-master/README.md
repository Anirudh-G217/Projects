# ChatBot_PS-1
When running the projects locally it is required to download all the packages required. Also need to shift the nlp_module.py, myqs.txt
and response generator.py to database_chatbot directory.
